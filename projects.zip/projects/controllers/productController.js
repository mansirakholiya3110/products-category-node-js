const Product = require('../models/productModel');

exports.getAllProducts = async (req, res) => {
    try {
        const products = await Product.find();
        res.render('products/list', { products });
    } catch (err) {
        res.status(500).send('Server Error');
    }
};

exports.createProduct = (req, res) => {
    res.render('products/new');
};

exports.addProduct = async (req, res) => {
    try {
        const product = new Product(req.body);
        await product.save();
        res.redirect('/products');
    } catch (err) {
        res.status(500).send('Server Error');
    }
};

exports.editProduct = async (req, res) => {
    try {
        const product = await Product.findById(req.params.id);
        res.render('products/edit', { product });
    } catch (err) {
        res.status(500).send('Server Error');
    }
};

exports.updateProduct = async (req, res) => {
    try {
        await Product.findByIdAndUpdate(req.params.id, req.body);
        res.redirect('/products');
    } catch (err) {
        res.status(500).send('Server Error');
    }
};

exports.deleteProduct = async (req, res) => {
    try {
        await Product.findByIdAndDelete(req.params.id);
        res.redirect('/products');
    } catch (err) {
        res.status(500).send('Server Error');
    }
};


exports.viewProductDetails = async (req, res) => {
    try {
        const product = await Product.findById(req.params.id);
        if (!product) {
            return res.status(404).send('Product not found');
        }
        res.render('products/details', { product });
    } catch (err) {
        res.status(500).send('Server Error');
    }
};