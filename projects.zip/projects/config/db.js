const mongoose = require('mongoose')

mongoose.connect('mongodb://127.0.0.1/dashboard')

const db = mongoose.connection

db.on('connected',(err)=>{
    if(err){
        console.log("db not connected");
    }else{
        console.log("db connected");
    }
})

