const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
    name: String,
    price: String,
    category: String,
    OperatingSystem:String,
    Brand: String,
    image: String,
    subcategory: String,
});

module.exports = mongoose.model('Product', productSchema);
