const express = require('express');
const router = express.Router();
const productController = require('../controllers/productController');

router.get('/', productController.getAllProducts);
router.get('/new', productController.createProduct);
router.post('/add', productController.addProduct);
router.get('/edit/:id', productController.editProduct);
router.post('/update/:id', productController.updateProduct);
router.get('/:id', productController.viewProductDetails);
router.post('/delete/:id', productController.deleteProduct);

// Define routes here
router.get('/', (req, res) => {
    res.send('Products route is working!');
});

module.exports = router;
